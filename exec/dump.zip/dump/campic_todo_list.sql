-- MySQL dump 10.13  Distrib 8.0.28, for Win64 (x86_64)
--
-- Host: i7C109.p.ssafy.io    Database: campic
-- ------------------------------------------------------
-- Server version	8.0.30-0ubuntu0.20.04.2

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `todo_list`
--

DROP TABLE IF EXISTS `todo_list`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `todo_list` (
  `todo_id` int NOT NULL,
  `done` bit(1) NOT NULL,
  `task` varchar(255) NOT NULL,
  `save_id` int DEFAULT NULL,
  PRIMARY KEY (`todo_id`),
  KEY `FKcixtsagd5c5akiq36nye50xob` (`save_id`),
  CONSTRAINT `FKcixtsagd5c5akiq36nye50xob` FOREIGN KEY (`save_id`) REFERENCES `liked_camp_list` (`save_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `todo_list`
--

LOCK TABLES `todo_list` WRITE;
/*!40000 ALTER TABLE `todo_list` DISABLE KEYS */;
INSERT INTO `todo_list` VALUES (1469,_binary '\0','나 아까 투두 썼던거 같은데',1389),(1626,_binary '\0','곤충채집',1619),(1627,_binary '\0','나뭇잎 모으기',1619),(1629,_binary '\0','모닥불',1619),(1648,_binary '\0','',1619),(1684,_binary '\0','고기',1683),(1685,_binary '\0','술',1683),(1686,_binary '\0','이히히히',1683),(1687,_binary '\0','빵빵',1683),(1693,_binary '\0','캠핑장 예약하기',1688),(1823,_binary '','캠핑의자',1819),(1824,_binary '','캠핑 물품 확인 전화하기',1819),(1826,_binary '','화로, 숯, ..',1819),(1829,_binary '\0','캠프파이어',1828),(1878,_binary '','공통 플젝',1819),(1911,_binary '\0','머물다 갑니다!',1910),(2086,_binary '','캠핑장 예약',2085),(2087,_binary '','근처 맛집 찾기',2085),(2088,_binary '','장 볼 리스트 만들기',2085),(2089,_binary '','텐트 구입',2085),(2126,_binary '\0','캠핑장 예약',2125),(2127,_binary '\0','근처 맛집 찾기',2125),(2128,_binary '\0','장 볼 리스트 만들기',2125),(2129,_binary '\0','텐트 구입',2125);
/*!40000 ALTER TABLE `todo_list` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-08-19  3:54:07
