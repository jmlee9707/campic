-- MySQL dump 10.13  Distrib 8.0.28, for Win64 (x86_64)
--
-- Host: i7C109.p.ssafy.io    Database: campic
-- ------------------------------------------------------
-- Server version	8.0.30-0ubuntu0.20.04.2

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `community`
--

DROP TABLE IF EXISTS `community`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `community` (
  `board_id` int NOT NULL,
  `click` int NOT NULL,
  `content` varchar(255) NOT NULL,
  `hashtag` varchar(255) DEFAULT NULL,
  `upload_date` datetime(6) DEFAULT NULL,
  `user_id` int DEFAULT NULL,
  PRIMARY KEY (`board_id`),
  KEY `FKfsfwlfb2ummfsb30q78wo6se0` (`user_id`),
  CONSTRAINT `FKfsfwlfb2ummfsb30q78wo6se0` FOREIGN KEY (`user_id`) REFERENCES `user` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `community`
--

LOCK TABLES `community` WRITE;
/*!40000 ALTER TABLE `community` DISABLE KEYS */;
INSERT INTO `community` VALUES (1991,2,'이쁘다 구름','# 구름','2022-08-18 12:14:15.225000',1810),(1993,1,'맛있는 바비큐','#고기 #캠핑 #소시지','2022-08-18 12:14:16.702000',1809),(1995,5,'노을이 보고 싶은 밤','#노을','2022-08-18 12:14:38.021000',1810),(1997,1,'마시멜로우 구이','# 마시멜로우 # 캠프파이어 # 장작','2022-08-18 12:15:11.215000',799),(1999,12,'제주도에서 소원 빌기','#바다','2022-08-18 12:15:54.412000',895),(2001,7,'숲 속에서 ','#캠핑','2022-08-18 12:17:00.763000',137),(2003,7,'산책로 걷기','#걷기 #산책로','2022-08-18 12:19:16.694000',799),(2005,3,'멋진 내 모습^~^','# 멋진 # 나','2022-08-18 12:19:21.441000',729),(2010,1,'숲속 감성 캠핑','#숲 #텐트 #조명','2022-08-18 12:21:22.708000',1809),(2013,2,'야경','#한강 #야경','2022-08-18 12:22:56.666000',1809),(2019,1,'여행 준비물 카메라','#여행 #준비물 #카메라','2022-08-18 12:25:52.120000',715),(2026,2,'에메랄드빛 바다','#바다색 #예쁨 #여행','2022-08-18 12:34:11.858000',2021),(2029,1,'모여있는 민들레','#꽃 #민들레 #꽃밭','2022-08-18 12:38:49.122000',2021),(2035,4,'갈대사이로 지는 해','#석양 #노을 #하늘','2022-08-18 12:49:50.453000',2021),(2042,1,'초록 계곡','#초록초록 #계곡 #물','2022-08-18 12:51:57.524000',2023),(2044,1,'오늘의 캠핑','#흐린날 #장비 #텐트','2022-08-18 12:52:38.389000',2023),(2047,1,'벚꽃놀이','#벚꽃 #봄 #봄여행','2022-08-18 12:56:15.097000',1809),(2057,2,'밤산책','#밤산책 #조명','2022-08-18 13:11:05.848000',1809),(2059,1,'유채꽃밭','#유채꽃 #꽃밭 #바람','2022-08-18 13:14:17.969000',799),(2063,3,'캠핑장 안 카페','#카페 #커피 #캠핑장','2022-08-18 13:17:16.428000',799),(2068,2,'빨간 숯불 ','#숯 #바베큐 #캠핑준비','2022-08-18 13:31:12.181000',137),(2070,9,'바다구경','#바닷가 #파도','2022-08-18 13:33:47.345000',137),(2075,2,'가을 산책길','#가을이 #왔으면 #좋겠다','2022-08-18 13:37:39.416000',137),(2130,1,'불타는 장작','#장작 #캠프파이어 #불멍','2022-08-18 17:20:14.270000',1809);
/*!40000 ALTER TABLE `community` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-08-19  3:54:09
