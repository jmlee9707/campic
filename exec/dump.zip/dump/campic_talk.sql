-- MySQL dump 10.13  Distrib 8.0.28, for Win64 (x86_64)
--
-- Host: i7C109.p.ssafy.io    Database: campic
-- ------------------------------------------------------
-- Server version	8.0.30-0ubuntu0.20.04.2

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `talk`
--

DROP TABLE IF EXISTS `talk`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `talk` (
  `talk_id` int NOT NULL,
  `click` int NOT NULL,
  `contents` longtext,
  `hashtag` varchar(255) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  `upload_date` datetime(6) DEFAULT NULL,
  `user_id` int DEFAULT NULL,
  PRIMARY KEY (`talk_id`),
  KEY `FKcuvdh01cnotcukbyvw910jo3g` (`user_id`),
  CONSTRAINT `FKcuvdh01cnotcukbyvw910jo3g` FOREIGN KEY (`user_id`) REFERENCES `user` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `talk`
--

LOCK TABLES `talk` WRITE;
/*!40000 ALTER TABLE `talk` DISABLE KEYS */;
INSERT INTO `talk` VALUES (1970,26,'<p>안녕하세요 ~~</p>\r\n\r\n<p>저도 참 캠핑 좋아하는데요&nbsp;</p>\r\n\r\n<p>요즘 캠핑이 인기라서 캠핑장 예약하는데에 다들 힘드실 텐데!!</p>\r\n\r\n<p>제가 인기 캠핑장 예약 꿀팁 알려드리려고 합니다.!!</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p>① 캠핑장 예약이 어떻게 이뤄지는지 확인 필요 !!</p>\r\n\r\n<p><strong>&rarr; 매일 예약이 가능한지 or 한 달 전에 가능한지</strong></p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p>② 캠핑장 카페에 가입하고 확인하기</p>\r\n\r\n<p><strong>&rarr; &lsquo;예약, 양도&rsquo; 등 키워드에 알람 설정 해놓고 꾸준히 확인</strong></p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p>③ 처음 취소 수수료 발생 날 재확인</p>\r\n\r\n<p><strong>&rarr; 마지막까지 망설이다 취소하는 경우 대비</strong></p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p>④ 캠핑 예약 사이트 꾸준히 모니터링</p>\r\n\r\n<p><strong>&rarr; 언제 자리가 날지 모르는 취소분 노리기</strong></p>\r\n','#인기캠핑장 #예약','인기 캠핑장 예약 꿀팁','2022-08-18 11:35:13.679000',895),(1973,36,'<p>안녕하세요 ~ 다들 캠핑 좋아하시나요??</p>\r\n\r\n<p>저도 캠핑을 좋아해서 자주 다니는데</p>\r\n\r\n<p>여름이라고 캠핑을 안갈 수는 없겠죠??</p>\r\n\r\n<p>그래서 저는 여름에도 즐겁게 캠핑을 다녀올 수 있도록</p>\r\n\r\n<p>몇가지 주의점에 대해 알려드리려고 글을 쓰게 되었습니다ㅎㅎㅎ</p>\r\n\r\n<p>다들 이 글 읽고 재밌는 캠핑 하셨으면 좋겠네요 ㅎㅎ</p>\r\n\r\n<p>첫번째,&nbsp;&nbsp;파쇄석이나 그나마 데크사이트가 있는 곳으로 가기!</p>\r\n\r\n<p>여름에 벌레가 많아서 잔디사이트는 추천하지 않아요~~</p>\r\n\r\n<p>둘째, 장비는 되도록이면 미니멀하게!</p>\r\n\r\n<p>일반적으로 여름에는 통풍이 잘되는 돔타입으로 준비하시는 것을 추천드립니다 ㅎㅎ</p>\r\n\r\n<p>셋째, 벌레에 대비하자 !</p>\r\n\r\n<p>여름 캠핑이 힘든 이유는 아마 벌레가 아닐까 싶은데요</p>\r\n\r\n<p>그렇기 대문 항상 상비약, 모기향, 벌레 퇴치기 등을 준비하시길</p>\r\n\r\n<p>넷째는 아이스박스 무조건 챙기기!</p>\r\n\r\n<p>마지막으로는 서큘레이터와 전기매트를 챙겨서</p>\r\n\r\n<p>더운 여름이지만 재밌는 캠핑 하시길 바랍니다 ~~&nbsp;</p>\r\n','#여름캠핑','여름 캠핑할 때 주의점','2022-08-18 11:47:04.439000',895),(1979,3,'<p>1. 신두리 사구센터</p>\r\n\r\n<p>2. 파주캠핑장-하늘연캠핑장</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p>추천 드립니다.</p>\r\n','# 캠핑당추천','자연이 이쁜 캠핑장 추천','2022-08-18 11:59:33.608000',1810),(1981,21,'<p>텐트 잘 치는법 입니다</p>\r\n\r\n<p>큰 텐트를 잘 치려면 이렇게 쳐야합니다.</p>\r\n','# 캠프 # 텐트 # 텐트치는법','텐트치는 법','2022-08-18 12:05:14.489000',1809),(2017,1,'<p>1. 우비</p>\r\n\r\n<p>2. 방수포</p>\r\n\r\n<p>3. 김장비닐</p>\r\n\r\n<p>4. 비상용난방용품</p>\r\n\r\n<p>!!!!!!</p>\r\n','#비오는날','비오는날 캠핑 준비물','2022-08-18 12:25:23.676000',1810),(2024,2,'<p>이번 주말에 다녀왔는데</p>\r\n\r\n<p>시설이 깔끔하더라구요~</p>\r\n\r\n<p>광주랑 가까워서 당일치기로 다녀올 수 있었어요</p>\r\n\r\n<p>추천드립니다.</p>\r\n','#담양 #오토캠핑','담양금성산성오토캠핑장 다녀온 후기','2022-08-18 12:33:35.553000',1810),(2031,24,'<p>여러분들 캠핑 많이들 가시죠?</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p>저도 참 좋아하는데요&nbsp;</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p>사진 잘찍기 위해서는 구도가 중요해요 !!!</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p>다음부터 꼭 참고하셔서 감성있는 사진 찍기 바랄게요 ~~</p>\r\n','#감성 #사진','캠핑 감성 사진 찍는법','2022-08-18 12:40:11.095000',137),(2033,1,'<p>안녕하세요~</p>\r\n\r\n<p>다들 캠핑 좋아하시나요???</p>\r\n\r\n<p>저도 캠핑 좋아해서 자주 떠나고는 하는데</p>\r\n\r\n<p>가끔 바쁜 일들을 마무리되었을 때</p>\r\n\r\n<p>생각 정리할 겸 혼자 떠나고는 한답니다!!!</p>\r\n\r\n<p>캠핑 좋아하는 캠픽러분들도 혼캠핑 한번 도전해보세요 ㅎㅎㅎ</p>\r\n\r\n<p>추천드립니다.</p>\r\n','#혼캠핑','혼자서 캠핑 즐기기','2022-08-18 12:42:52.305000',729),(2040,2,'<p>안녕하세요?!</p>\r\n\r\n<p>다들 캠핑갈 때 무조건 챙기는 음식이 있다면 무엇인가요?</p>\r\n\r\n<p>저는 마시멜로를 무조건 사갑니다ㅎㅎㅎ</p>\r\n\r\n<p>마시멜로를 4겹으로 벗겨먹는 맛!!!</p>\r\n\r\n<p>다들 한번 맛보신다면!!</p>\r\n\r\n<p>다들 빠지실 것이라 저는 확십합니다~~</p>\r\n\r\n<p>다음에 꼭 한번씩 시도해보세요</p>\r\n','#마시멜로','마시멜로 맛있게 굽는방법','2022-08-18 12:51:00.160000',729),(2049,3,'<p>초보 캠픽러분들이 어려워 하는게 있다면&nbsp;</p>\r\n\r\n<p>바로 불 피우는 것일 텐데요</p>\r\n\r\n<p>토치를 사용한다면 금방 피우실 수 있을 거에요~~</p>\r\n\r\n<p>&nbsp;</p>\r\n','#장작','장작 불 피우기','2022-08-18 12:56:21.783000',895),(2051,3,'<p>캠핑 용품 추천 드립니다.</p>\r\n\r\n<p>이 텐트는 접이식 텐트라 좋더라구요~</p>\r\n\r\n<p>추천 드려요~~</p>\r\n','#텐트','캠핑 용품 추천','2022-08-18 12:58:50.712000',895),(2053,23,'<p>캠핑 가면 빠질 수 없는 바베큐!!!</p>\r\n\r\n<p>열심히 놀고나면 당연히 맛있을 수 밖에 없죠 ㅎ</p>\r\n\r\n<p>그리고 무조건 소맥과 함께 ㅎㅎㅎ</p>\r\n','#바베큐','바베큐 맛있게 먹는법','2022-08-18 13:00:52.795000',2023),(2055,3,'<p>바다 근처 캠핑장 추천 해주세요~</p>\r\n','#바다 #캠핑','바다 근처 캠핑장','2022-08-18 13:08:30.930000',799),(2115,5,'<p>구름이 이쁜곳이 궁금하신가요?</p>\r\n\r\n<p>사실 날씨가 좋으면 구름은 이쁜 것 같습니다 ㅎㅎ</p>\r\n\r\n<p>다들 아는 사실이었다구요??</p>\r\n\r\n<p>그래도 여기 들어온김에 허리도 펴고 기지개도 펴고 하늘도 한번 보고 합시당 ~~&nbsp;</p>\r\n\r\n<p>&nbsp;</p>\r\n','#구름','구름이 이쁜곳','2022-08-18 17:04:35.116000',1810);
/*!40000 ALTER TABLE `talk` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-08-19  3:54:20
